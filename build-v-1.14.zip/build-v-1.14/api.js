window.__APP_CONFIG__ = {
  API_URL: "http://localhost:3001/api/data",
};

//"http://3.144.195.107:3000/api/data"