window.__APP_CONFIG__ = {
  API_URL: "http://3.144.195.107:3000/api/data",
  
};